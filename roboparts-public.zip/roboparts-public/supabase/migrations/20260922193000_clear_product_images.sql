-- Product photos are managed only from the Admin panel.
-- Clear any existing product image URLs so products start without photos.
UPDATE public.products
SET image_url = NULL
WHERE image_url IS NOT NULL;
