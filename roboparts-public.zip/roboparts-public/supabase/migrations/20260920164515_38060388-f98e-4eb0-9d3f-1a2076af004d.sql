-- Split anon/authenticated read policies so anon never needs is_admin()
DROP POLICY "products public read" ON public.products;
CREATE POLICY "products anon read" ON public.products FOR SELECT TO anon USING (is_active);
CREATE POLICY "products auth read" ON public.products FOR SELECT TO authenticated USING (is_active OR public.is_admin());

DROP POLICY "projects public read" ON public.projects;
CREATE POLICY "projects anon read" ON public.projects FOR SELECT TO anon USING (is_published);
CREATE POLICY "projects auth read" ON public.projects FOR SELECT TO authenticated USING (is_published OR public.is_admin());

DROP POLICY "categories public read" ON public.categories;
CREATE POLICY "categories read" ON public.categories FOR SELECT TO anon, authenticated USING (true);

DROP POLICY "settings public read" ON public.website_settings;
CREATE POLICY "settings read" ON public.website_settings FOR SELECT TO anon, authenticated USING (true);

DROP POLICY "ai settings read" ON public.ai_settings;
CREATE POLICY "ai settings read" ON public.ai_settings FOR SELECT TO anon, authenticated USING (true);

-- Lock down SECURITY DEFINER functions
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;