-- ENUMS
CREATE TYPE public.app_role AS ENUM ('admin','user');
CREATE TYPE public.purchase_status AS ENUM ('Pending','Confirmed','Preparing','Completed','Cancelled');
CREATE TYPE public.chat_sender AS ENUM ('user','ai','admin');

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$
LANGUAGE plpgsql SET search_path = public;

-- PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- USER ROLES
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(auth.uid(), 'admin');
$$;

CREATE POLICY "own profile read" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id OR public.is_admin());
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id OR public.is_admin()) WITH CHECK (true);
CREATE POLICY "roles read own" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.is_admin());

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'))
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- CATEGORIES
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories public read" ON public.categories FOR SELECT USING (true);
CREATE POLICY "categories admin write" ON public.categories FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER trg_categories_updated BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- PRODUCTS
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  sku TEXT UNIQUE,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  short_description TEXT,
  full_description TEXT,
  applications TEXT,
  specifications TEXT,
  tags TEXT[] NOT NULL DEFAULT '{}',
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  stock_quantity INT NOT NULL DEFAULT 0,
  image_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_products_category ON public.products(category_id);
CREATE INDEX idx_products_active ON public.products(is_active);
CREATE INDEX idx_products_name ON public.products(lower(name));
GRANT SELECT ON public.products TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products public read" ON public.products FOR SELECT USING (is_active OR public.is_admin());
CREATE POLICY "products admin write" ON public.products FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER trg_products_updated BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- PROJECTS
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT,
  description TEXT,
  difficulty TEXT NOT NULL DEFAULT 'Fillestar',
  components TEXT,
  image_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.projects TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "projects public read" ON public.projects FOR SELECT USING (is_published OR public.is_admin());
CREATE POLICY "projects admin write" ON public.projects FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- CARTS
CREATE TABLE public.carts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.carts TO authenticated;
GRANT ALL ON public.carts TO service_role;
ALTER TABLE public.carts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own cart" ON public.carts FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.cart_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id UUID NOT NULL REFERENCES public.carts(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (cart_id, product_id)
);
CREATE INDEX idx_cart_items_cart ON public.cart_items(cart_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cart_items TO authenticated;
GRANT ALL ON public.cart_items TO service_role;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own cart items" ON public.cart_items FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.carts c WHERE c.id = cart_id AND c.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.carts c WHERE c.id = cart_id AND c.user_id = auth.uid()));
CREATE TRIGGER trg_cart_items_updated BEFORE UPDATE ON public.cart_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- CHAT
CREATE TABLE public.chat_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  title TEXT NOT NULL DEFAULT 'Bisedë e re',
  admin_takeover BOOLEAN NOT NULL DEFAULT false,
  is_open BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_conv_user ON public.chat_conversations(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_conversations TO authenticated;
GRANT ALL ON public.chat_conversations TO service_role;
ALTER TABLE public.chat_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "conv own read" ON public.chat_conversations FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "conv own insert" ON public.chat_conversations FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "conv update" ON public.chat_conversations FOR UPDATE TO authenticated USING (auth.uid() = user_id OR public.is_admin()) WITH CHECK (true);
CREATE POLICY "conv admin delete" ON public.chat_conversations FOR DELETE TO authenticated USING (public.is_admin());
CREATE TRIGGER trg_conv_updated BEFORE UPDATE ON public.chat_conversations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.chat_conversations(id) ON DELETE CASCADE,
  sender public.chat_sender NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_msg_conv ON public.chat_messages(conversation_id, created_at);
GRANT SELECT, INSERT ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "msg read" ON public.chat_messages FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = conversation_id AND (c.user_id = auth.uid() OR public.is_admin())));
CREATE POLICY "msg insert" ON public.chat_messages FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.chat_conversations c WHERE c.id = conversation_id AND (c.user_id = auth.uid() OR public.is_admin())));

-- PURCHASE REQUESTS
CREATE TABLE public.purchase_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  conversation_id UUID REFERENCES public.chat_conversations(id) ON DELETE SET NULL,
  status public.purchase_status NOT NULL DEFAULT 'Pending',
  total_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  contact_name TEXT,
  contact_phone TEXT,
  notes TEXT,
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pr_user ON public.purchase_requests(user_id);
CREATE INDEX idx_pr_status ON public.purchase_requests(status);
GRANT SELECT, INSERT, UPDATE ON public.purchase_requests TO authenticated;
GRANT ALL ON public.purchase_requests TO service_role;
ALTER TABLE public.purchase_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pr read" ON public.purchase_requests FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "pr insert" ON public.purchase_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pr update admin" ON public.purchase_requests FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER trg_pr_updated BEFORE UPDATE ON public.purchase_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.purchase_request_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID NOT NULL REFERENCES public.purchase_requests(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  unit_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  quantity INT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pri_request ON public.purchase_request_items(request_id);
GRANT SELECT, INSERT ON public.purchase_request_items TO authenticated;
GRANT ALL ON public.purchase_request_items TO service_role;
ALTER TABLE public.purchase_request_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pri read" ON public.purchase_request_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.purchase_requests r WHERE r.id = request_id AND (r.user_id = auth.uid() OR public.is_admin())));
CREATE POLICY "pri insert" ON public.purchase_request_items FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.purchase_requests r WHERE r.id = request_id AND r.user_id = auth.uid()));

-- NOTIFICATIONS
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  related_id UUID,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notif_read ON public.notifications(is_read, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif admin read" ON public.notifications FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "notif insert" ON public.notifications FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "notif admin update" ON public.notifications FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "notif admin delete" ON public.notifications FOR DELETE TO authenticated USING (public.is_admin());

-- WEBSITE SETTINGS
CREATE TABLE public.website_settings (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  site_name TEXT NOT NULL DEFAULT 'eleteonicenginercomponents',
  logo_url TEXT,
  hero_title TEXT NOT NULL DEFAULT 'Komponentë elektronikë për inxhinierë dhe studentë',
  hero_subtitle TEXT NOT NULL DEFAULT 'Gjithçka që ju nevojitet për prototipet tuaja: Arduino, ESP32, sensorë, ekrane, motorë dhe më shumë.',
  contact_email TEXT,
  contact_phone TEXT,
  contact_address TEXT,
  facebook_url TEXT,
  instagram_url TEXT,
  tiktok_url TEXT,
  youtube_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.website_settings TO anon;
GRANT SELECT, INSERT, UPDATE ON public.website_settings TO authenticated;
GRANT ALL ON public.website_settings TO service_role;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings public read" ON public.website_settings FOR SELECT USING (true);
CREATE POLICY "settings admin write" ON public.website_settings FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
INSERT INTO public.website_settings (id, contact_email, contact_phone) VALUES (1, 'info@example.com', '+355 00 000 0000');

-- AI SETTINGS
CREATE TABLE public.ai_settings (
  id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  enabled BOOLEAN NOT NULL DEFAULT true,
  model TEXT NOT NULL DEFAULT 'google/gemini-3.8-flash',
  system_prompt TEXT NOT NULL DEFAULT 'Ti je asistenti i dyqanit të komponentëve elektronikë. Ndihmo studentët të zgjedhin komponentë për projektet e tyre, shpjego produktet dhe sugjero alternativa. Përgjigju gjithmonë në shqip.',
  welcome_message TEXT NOT NULL DEFAULT 'Përshëndetje! Si mund t''ju ndihmoj me projektin tuaj elektronik?',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ai_settings TO anon;
GRANT SELECT, INSERT, UPDATE ON public.ai_settings TO authenticated;
GRANT ALL ON public.ai_settings TO service_role;
ALTER TABLE public.ai_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ai settings read" ON public.ai_settings FOR SELECT USING (true);
CREATE POLICY "ai settings admin write" ON public.ai_settings FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
INSERT INTO public.ai_settings (id) VALUES (1);

-- PRODUCT IMAGE STORAGE
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- STORAGE POLICIES
CREATE POLICY "product images read" ON storage.objects FOR SELECT USING (bucket_id = 'product-images');
CREATE POLICY "product images admin insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'product-images' AND public.is_admin());
CREATE POLICY "product images admin update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'product-images' AND public.is_admin());
CREATE POLICY "product images admin delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'product-images' AND public.is_admin());

-- REALTIME
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_conversations;

-- SEED CATEGORIES
INSERT INTO public.categories (name, slug, description, sort_order) VALUES
 ('Arduino','arduino','Borde Arduino dhe pajisje shtesë',1),
 ('ESP32 & WiFi','esp32','Borde ESP32, ESP8266 dhe module WiFi',2),
 ('Sensorë','sensore','Sensorë temperature, lëvizjeje, distance dhe më shumë',3),
 ('Ekrane','ekrane','Ekrane LCD, OLED dhe TFT',4),
 ('Motorë','motore','Motorë DC, servo dhe stepper',5),
 ('Drejtues Motorësh','drejtues-motoresh','Module drejtuese për motorë',6),
 ('Rele','rele','Module rele dhe ndërprerës',7),
 ('Module Komunikimi','komunikim','Bluetooth, RF, LoRa, CAN dhe GSM',8),
 ('Ushqim & Energji','ushqim','Rregullatorë, bateri dhe konvertues',9),
 ('Komponentë Pasivë','pasive','Rezistorë, kondensatorë, induktorë',10),
 ('Robotikë','robotike','Shasi, rrota dhe kite robotike',11),
 ('Prototipim','prototipim','Breadboard, kabllo dhe vegla',12);

-- SEED PRODUCTS
INSERT INTO public.products (name, slug, sku, category_id, short_description, full_description, applications, specifications, tags, price, stock_quantity)
SELECT v.name, v.slug, v.sku, c.id, v.short_desc, v.full_desc, v.apps, v.specs, v.tags, v.price, v.stock
FROM (VALUES
 ('Arduino UNO R3','arduino-uno-r3','ARD-001','arduino','Bordi klasik për fillestarë dhe prototipe.','Arduino UNO R3 është bordi më i përdorur për mësim dhe prototipim, i bazuar në mikrokontrollerin ATmega328P.','Projekte shkollore, automatizim, robotikë fillestare','Mikrokontroller: ATmega328P; Tension: 5V; Pina dixhitalë: 14; Pina analogë: 6', ARRAY['arduino','mcu'], 1500.00, 25),
 ('Arduino Nano','arduino-nano','ARD-002','arduino','Version kompakt i Arduino UNO.','Arduino Nano ofron të njëjtat mundësi si UNO në një format shumë të vogël, ideal për breadboard.','Prototipe kompakte, dronë, pajisje portative','Mikrokontroller: ATmega328P; USB: Mini-B; Tension: 5V', ARRAY['arduino','nano'], 900.00, 40),
 ('Arduino Mega 2560','arduino-mega-2560','ARD-003','arduino','Shumë pina I/O për projekte të mëdha.','Arduino Mega 2560 ka 54 pina dixhitalë dhe memorie më të madhe për projekte komplekse.','Printera 3D, CNC, sisteme me shumë sensorë','Mikrokontroller: ATmega2560; Pina dixhitalë: 54; Flash: 256KB', ARRAY['arduino','mega'], 3200.00, 10),
 ('Arduino Pro Micro','arduino-pro-micro','ARD-004','arduino','Bord me USB HID të integruar.','Pro Micro bazohet në ATmega32U4 dhe mund të emulojë tastierë ose maus.','Tastiera custom, kontrollues lojërash','MCU: ATmega32U4; USB: Micro; Tension: 5V', ARRAY['arduino','usb'], 1200.00, 15),
 ('Arduino Sensor Shield V5','arduino-sensor-shield','ARD-005','arduino','Shield për lidhje të lehtë sensorësh.','Shield që zgjeron pinat e Arduino UNO në konektorë 3-pinësh për sensorë.','Prototipim i shpejtë, arsim','Përputhshmëri: Arduino UNO; Konektorë: 3-pin', ARRAY['arduino','shield'], 700.00, 20),
 ('ESP32 DevKit V1','esp32-devkit-v1','ESP-001','esp32','Bord WiFi + Bluetooth me dy bërthama.','ESP32 DevKit V1 është një bord i fuqishëm me WiFi dhe Bluetooth i integruar.','IoT, shtëpi inteligjente, monitorim në distancë','CPU: Dual-core 240MHz; WiFi: 802.11 b/g/n; Bluetooth: 4.2', ARRAY['esp32','iot','wifi'], 1400.00, 30),
 ('ESP32-CAM','esp32-cam','ESP-002','esp32','ESP32 me kamerë OV2640.','Modul ESP32 me kamerë dhe slot microSD, ideal për projekte me video.','Kamera sigurie, njohje objektesh, robotikë','Kamera: OV2640 2MP; WiFi: po; Slot: microSD', ARRAY['esp32','camera'], 1800.00, 12),
 ('ESP8266 NodeMCU','esp8266-nodemcu','ESP-003','esp32','Bord WiFi ekonomik.','NodeMCU me ESP8266 është zgjidhje e lirë për projekte IoT me WiFi.','Sensorë online, automatizim shtëpie','MCU: ESP8266; WiFi: 802.11 b/g/n; GPIO: 11', ARRAY['esp8266','wifi'], 1000.00, 22),
 ('ESP32-S3 DevKit','esp32-s3-devkit','ESP-004','esp32','ESP32 i gjeneratës së re me AI.','ESP32-S3 mbështet përpunim vektorial për aplikime AI në skaj.','Zë, vizion kompjuterik, IoT i avancuar','CPU: Xtensa LX7 dual-core; USB: OTG; PSRAM: 8MB', ARRAY['esp32','ai'], 2400.00, 0),
 ('Sensor Temperature DHT11','dht11','SEN-001','sensore','Sensor temperature dhe lagështie.','DHT11 mat temperaturën dhe lagështinë me dalje dixhitale, i lehtë për t''u përdorur.','Stacione moti, monitorim ambienti','Temperatura: 0-50°C; Lagështia: 20-90%; Dalja: dixhitale', ARRAY['sensor','temperature'], 350.00, 50),
 ('Sensor DHT22','dht22','SEN-002','sensore','Version më i saktë i DHT11.','DHT22 ofron saktësi dhe interval më të gjerë matjeje se DHT11.','Sera, laboratorë, projekte precize','Temperatura: -40 deri 80°C; Saktësia: ±0.5°C', ARRAY['sensor','temperature'], 750.00, 25),
 ('Sensor Ultrasonik HC-SR04','hc-sr04','SEN-003','sensore','Matje distance me ultratinguj.','HC-SR04 mat distancën 2-400cm me ultratinguj.','Robotë që shmangin pengesa, matje niveli','Distanca: 2-400cm; Tension: 5V; Këndi: 15°', ARRAY['sensor','distance'], 400.00, 45),
 ('Sensor PIR HC-SR501','hc-sr501','SEN-004','sensore','Detektor lëvizjeje infra të kuqe.','Sensor PIR që detekton lëvizjen e njerëzve deri në 7 metra.','Alarme, ndriçim automatik','Rrezja: 3-7m; Këndi: 120°; Tension: 5-20V', ARRAY['sensor','pir'], 450.00, 30),
 ('Sensor Gazi MQ-2','mq-2','SEN-005','sensore','Detekton tym dhe gaze të djegshme.','MQ-2 është sensor analog për LPG, tym dhe propan.','Alarme zjarri, siguri shtëpie','Dalja: analoge + dixhitale; Tension: 5V', ARRAY['sensor','gas'], 500.00, 18),
 ('Sensor Drite LDR','ldr-modul','SEN-006','sensore','Modul sensor për intensitetin e dritës.','Modul me fotorezistencë për matjen e dritës së ambientit.','Ndriçim automatik, ndjekës diellor','Dalja: analoge/dixhitale; Tension: 3.3-5V', ARRAY['sensor','light'], 250.00, 60),
 ('Sensor MPU-6050','mpu6050','SEN-007','sensore','Akselerometër dhe xhiroskop 6 akse.','MPU-6050 kombinon akselerometrin dhe xhiroskopin me komunikim I2C.','Dronë, stabilizim, gjeste','Akset: 6; Interfejsi: I2C; Tension: 3-5V', ARRAY['sensor','imu'], 700.00, 20),
 ('Sensor Lagështie Toke','soil-moisture','SEN-008','sensore','Mat lagështinë e tokës.','Sensor kapacitiv për matjen e lagështisë së tokës në vazo dhe sera.','Ujitje automatike, bujqësi inteligjente','Dalja: analoge; Tension: 3.3-5V', ARRAY['sensor','soil'], 350.00, 35),
 ('Sensor Rrjedhjeje Uji YF-S201','yf-s201','SEN-009','sensore','Mat rrjedhjen e ujit.','Sensor me turbinë Hall për matjen e sasisë së ujit që kalon.','Sisteme ujitjeje, matës uji','Rrjedhja: 1-30 L/min; Tension: 5-18V', ARRAY['sensor','water'], 900.00, 8),
 ('Ekran LCD 16x2 me I2C','lcd-1602-i2c','DIS-001','ekrane','Ekran tekstual me vetëm 2 kabllo.','LCD 16x2 me modul I2C për lidhje të thjeshtë me Arduino.','Menu, matës, projekte shkollore','Rreshta: 2x16; Interfejsi: I2C; Tension: 5V', ARRAY['display','lcd'], 650.00, 28),
 ('Ekran OLED 0.96 inç I2C','oled-096','DIS-002','ekrane','Ekran i vogël grafik OLED.','Ekran OLED 128x64 me kontrast të lartë dhe konsum të ulët.','Pajisje portative, matës, orë','Rezolucioni: 128x64; Interfejsi: I2C; Ngjyra: e bardhë', ARRAY['display','oled'], 700.00, 26),
 ('Ekran TFT 2.4 inç me Touch','tft-24','DIS-003','ekrane','Ekran me ngjyra dhe prekje.','Ekran TFT 2.4 inç me kontrollues ILI9341 dhe panel prekjeje.','Ndërfaqe grafike, instrumente','Rezolucioni: 320x240; Interfejsi: SPI', ARRAY['display','tft'], 1600.00, 7),
 ('Ekran 7-Segment 4 Shifror','seven-segment-4','DIS-004','ekrane','Ekran numerik me TM1637.','Modul 4 shifror me drejtues TM1637 për numra dhe orë.','Numërues, orë, matës','Shifra: 4; Drejtues: TM1637; Tension: 3.3-5V', ARRAY['display','7segment'], 400.00, 30),
 ('Motor Servo SG90','servo-sg90','MOT-001','motore','Servo i vogël 9g.','Servo motor SG90 me rrotullim 180 gradë për projekte të vogla.','Krahë robotikë, dyer automatike','Momenti: 1.8 kg·cm; Këndi: 180°; Tension: 4.8-6V', ARRAY['motor','servo'], 450.00, 40),
 ('Motor Servo MG996R','servo-mg996r','MOT-002','motore','Servo me ingranazhe metalike.','MG996R ofron moment të lartë me ingranazhe metalike.','Robotë me peshë, timon RC','Momenti: 11 kg·cm; Tension: 4.8-7.2V', ARRAY['motor','servo'], 1200.00, 14),
 ('Motor Stepper 28BYJ-48 + ULN2003','stepper-28byj48','MOT-003','motore','Set motor stepper me drejtues.','Motor stepper 5V me bordin drejtues ULN2003 të përfshirë.','Pozicionim i saktë, kamera slider','Hapa: 2048/rrotullim; Tension: 5V', ARRAY['motor','stepper'], 700.00, 22),
 ('Motor DC me Reduktor TT','motor-dc-tt','MOT-004','motore','Motor DC me rrotë për robotë.','Motor DC 6V me reduktor plastik, ideal për shasi robotike.','Robotë me rrota, makina të vogla','Tension: 3-6V; Raporti: 1:48', ARRAY['motor','dc'], 400.00, 50),
 ('Motor NEMA 17','nema-17','MOT-005','motore','Motor stepper industrial i vogël.','NEMA 17 përdoret gjerësisht në printera 3D dhe CNC.','Printera 3D, CNC','Momenti: 0.4 N·m; Hapi: 1.8°', ARRAY['motor','stepper'], 2600.00, 0),
 ('Drejtues Motori L298N','l298n','DRV-001','drejtues-motoresh','Drejtues me dy kanale për motorë DC.','Moduli L298N kontrollon dy motorë DC ose një stepper.','Robotë me rrota, makina RC','Kanale: 2; Rryma: 2A/kanal; Tension: 5-35V', ARRAY['driver','motor'], 600.00, 25),
 ('Drejtues Motori L293D','l293d','DRV-002','drejtues-motoresh','Çip drejtues H-Bridge.','L293D është çip i thjeshtë për kontroll motorësh të vegjël.','Projekte fillestare, robotë të vegjël','Rryma: 600mA/kanal; Tension: 4.5-36V', ARRAY['driver','ic'], 250.00, 45),
 ('Drejtues A4988','a4988','DRV-003','drejtues-motoresh','Drejtues stepper me microstepping.','A4988 përdoret për të drejtuar motorë stepper me saktësi.','Printera 3D, CNC','Microstepping: deri 1/16; Rryma: 2A', ARRAY['driver','stepper'], 450.00, 30),
 ('Modul Rele 1 Kanal 5V','rele-1ch','REL-001','rele','Kontrollo pajisje 220V me 5V.','Modul rele me optoizolim për të kontrolluar pajisje me tension të lartë.','Ndriçim, pompa, automatizim','Kanale: 1; Kontakti: 10A 250VAC; Tension: 5V', ARRAY['relay'], 350.00, 40),
 ('Modul Rele 4 Kanale 5V','rele-4ch','REL-002','rele','Katër rele në një bord.','Modul me 4 rele për kontroll të shumë pajisjeve.','Shtëpi inteligjente, panele kontrolli','Kanale: 4; Kontakti: 10A 250VAC', ARRAY['relay'], 900.00, 18),
 ('Rele Solid State SSR-25DA','ssr-25da','REL-003','rele','Rele elektronike pa pjesë lëvizëse.','SSR për ndërrime të shpeshta dhe të heshtura.','Kontroll temperature, ngrohës','Rryma: 25A; Dalja: 24-380VAC', ARRAY['relay','ssr'], 1500.00, 6),
 ('Modul Bluetooth HC-05','hc-05','COM-001','komunikim','Komunikim serial me telefon.','HC-05 mundëson lidhje Bluetooth serial me Arduino.','Kontroll nga telefoni, robotë','Bluetooth: 2.0; Baud: 9600 default', ARRAY['bluetooth'], 800.00, 20),
 ('Modul NRF24L01','nrf24l01','COM-002','komunikim','Komunikim radio 2.4GHz.','NRF24L01 për komunikim pa tel midis dy bordeve.','Telemetri, dronë, sensorë të largët','Frekuenca: 2.4GHz; Rrezja: deri 100m', ARRAY['rf','wireless'], 450.00, 30),
 ('Modul LoRa SX1278 433MHz','lora-sx1278','COM-003','komunikim','Komunikim në distanca të gjata.','Modul LoRa për transmetim deri disa kilometra me konsum të ulët.','Bujqësi, monitorim i largët','Frekuenca: 433MHz; Rrezja: deri 5km', ARRAY['lora','wireless'], 1700.00, 9),
 ('Modul GSM SIM800L','sim800l','COM-004','komunikim','Dërgo SMS dhe lidhu në rrjet celular.','SIM800L mundëson thirrje, SMS dhe GPRS.','Alarme SMS, gjurmim','Bandat: Quad-band; Tension: 3.7-4.2V', ARRAY['gsm','sms'], 1900.00, 5),
 ('Modul RFID RC522','rc522','COM-005','komunikim','Lexues kartash RFID 13.56MHz.','RC522 lexon dhe shkruan karta RFID me SPI.','Kontroll aksesi, prezencë','Frekuenca: 13.56MHz; Interfejsi: SPI', ARRAY['rfid'], 600.00, 24),
 ('Modul CAN MCP2515','mcp2515','COM-006','komunikim','Interfejs CAN bus për Arduino.','MCP2515 me TJA1050 për komunikim CAN në automjete.','Automotive, OBD, industri','Shpejtësia: 1Mbps; Interfejsi: SPI', ARRAY['can','automotive'], 850.00, 10),
 ('Rregullator LM2596 Step-Down','lm2596','PWR-001','ushqim','Konvertues DC-DC i rregullueshëm.','Modul step-down për të ulur tensionin me efikasitet të lartë.','Ushqim projekti, bateri','Hyrja: 4-35V; Dalja: 1.25-30V; Rryma: 3A', ARRAY['power','dcdc'], 450.00, 35),
 ('Modul Ngarkimi TP4056','tp4056','PWR-002','ushqim','Karikues për bateri Li-Ion.','TP4056 me mbrojtje për karikimin e baterive 18650.','Pajisje portative, powerbank','Rryma: 1A; Hyrja: microUSB 5V', ARRAY['power','battery'], 300.00, 40),
 ('Bateri 18650 3.7V','bateri-18650','PWR-003','ushqim','Bateri e rikarikueshme Li-Ion.','Bateri 18650 për projekte portative.','Robotë, pajisje portative','Tension: 3.7V; Kapaciteti: 2000mAh', ARRAY['battery'], 550.00, 30),
 ('Ushqyes 12V 2A','adapter-12v-2a','PWR-004','ushqim','Adapter muri 12V.','Ushqyes i stabilizuar 12V 2A me fishë DC.','Rripa LED, motorë, rele','Dalja: 12V 2A; Fisha: 5.5x2.1mm', ARRAY['power','adapter'], 900.00, 16),
 ('Panel Diellor 6V 1W','panel-diellor-6v','PWR-005','ushqim','Panel i vogël fotovoltaik.','Panel diellor për projekte me energji të rinovueshme.','IoT në terren, karikim baterish','Tension: 6V; Fuqia: 1W', ARRAY['solar','power'], 800.00, 0),
 ('Set Rezistorësh 600 copë','set-rezistore','PAS-001','pasive','Rezistorë të vlerave të ndryshme.','Set me 30 vlera rezistorësh 1/4W, nga 10 Ohm deri 1 MOhm.','Çdo qark elektronik','Toleranca: 5%; Fuqia: 1/4W; Copë: 600', ARRAY['resistor','kit'], 1100.00, 20),
 ('Set Kondensatorësh Keramikë','set-kondensatore','PAS-002','pasive','Kondensatorë keramikë të asortuar.','Set kondensatorësh nga 10pF deri 100nF.','Filtrim, oshilatorë','Copë: 300; Tension: 50V', ARRAY['capacitor','kit'], 900.00, 18),
 ('Set Kondensatorësh Elektrolitikë','set-elektrolitike','PAS-003','pasive','Kondensatorë elektrolitikë të asortuar.','Set me vlera 1uF - 1000uF.','Ushqim, filtrim','Copë: 120; Tension: 16-50V', ARRAY['capacitor'], 950.00, 12),
 ('Set LED 5mm 5 Ngjyra','set-led','PAS-004','pasive','LED të ndryshëm për prototipim.','Set me 100 LED në 5 ngjyra.','Indikatorë, sinjalizim','Diametri: 5mm; Copë: 100', ARRAY['led','kit'], 500.00, 45),
 ('Set Diodash 1N4007','set-diode','PAS-005','pasive','Dioda drejtuese standarde.','Set me 50 dioda 1N4007.','Mbrojtje, drejtim rryme','Tension: 1000V; Rryma: 1A', ARRAY['diode'], 300.00, 30),
 ('Set Tranzistorësh NPN/PNP','set-tranzistore','PAS-006','pasive','Tranzistorë të asortuar.','Set me tranzistorë BC547, BC557, 2N2222 etj.','Amplifikim, ndërrim','Copë: 100; Tipe: 8', ARRAY['transistor','kit'], 750.00, 15),
 ('Potenciometër 10K','potenciometer-10k','PAS-007','pasive','Rezistencë e rregullueshme.','Potenciometër rrotullues 10K me bosht.','Rregullim volumi, kalibrim','Vlera: 10 kOhm; Fuqia: 0.5W', ARRAY['potentiometer'], 150.00, 60),
 ('Shasi Robot 2WD','shasi-2wd','ROB-001','robotike','Kit shasi me dy motorë.','Shasi akrilike me dy motorë TT, rrota dhe mbajtëse baterish.','Robotë ndjekës vije, makina të kontrolluara','Rrota: 2 + 1 kastor; Materiali: akrilik', ARRAY['robot','chassis'], 2200.00, 10),
 ('Shasi Robot 4WD','shasi-4wd','ROB-002','robotike','Kit shasi me katër motorë.','Shasi me 4 motorë për terren më të vështirë.','Robotë eksplorues, projekte diplome','Motorë: 4; Materiali: akrilik', ARRAY['robot','chassis'], 3400.00, 6),
 ('Krah Robotik 6 DOF','krah-robotik','ROB-003','robotike','Kit krahu robotik me servo.','Krah robotik metalik me 6 gradë lirie (servo nuk përfshihen).','Automatizim, demonstrime','DOF: 6; Materiali: alumin', ARRAY['robot','arm'], 8500.00, 3),
 ('Sensor Ndjekës Vije 5 Kanale','line-follower-5ch','ROB-004','robotike','Modul për robotë ndjekës vije.','Modul me 5 sensorë IR për ndjekjen e vijës.','Gara robotësh, projekte shkollore','Kanale: 5; Tension: 5V', ARRAY['robot','ir'], 850.00, 14),
 ('Rrotë Enkoder për Motorë TT','rrote-enkoder','ROB-005','robotike','Disk enkoder për matje shpejtësie.','Set diskesh enkoder me sensor optik.','Odometri, kontroll shpejtësie','Copë: 2; Tension: 3.3-5V', ARRAY['robot','encoder'], 400.00, 20),
 ('Breadboard 830 Pika','breadboard-830','PRO-001','prototipim','Breadboard standarde pa saldim.','Breadboard 830 pika për prototipim të shpejtë.','Çdo prototip elektronik','Pika: 830; Përmasa: 165x55mm', ARRAY['breadboard'], 550.00, 40),
 ('Set Kabllo Jumper 120 copë','kabllo-jumper','PRO-002','prototipim','Kabllo M-M, M-F, F-F.','Set kabllosh jumper 20cm në tre kombinime.','Lidhje breadboard','Copë: 120; Gjatësia: 20cm', ARRAY['jumper','cable'], 500.00, 50),
 ('Saldatriçe 60W me Rregullim','saldatrice-60w','PRO-003','prototipim','Hekur saldimi me temperaturë të rregullueshme.','Saldatriçe 60W me majë të ndërrueshme.','Montim qarqesh, riparime','Fuqia: 60W; Temperatura: 200-450°C', ARRAY['tool','soldering'], 2400.00, 8),
 ('Multimetër Dixhital DT830B','multimeter-dt830b','PRO-004','prototipim','Matës tensioni, rryme dhe rezistence.','Multimetër bazik për laborator dhe shtëpi.','Diagnostikim, matje','Ekrani: 3.5 shifra; DC/AC: po', ARRAY['tool','multimeter'], 1300.00, 12),
 ('Set PCB Prototip','pcb-prototip','PRO-005','prototipim','Borde të gjelbra për saldim.','Set bordesh prototipimi të përmasave të ndryshme.','Qarqe përfundimtare','Copë: 10; Përmasa: të ndryshme', ARRAY['pcb'], 700.00, 22),
 ('Kuti Plastike Projekti','kuti-projekti','PRO-006','prototipim','Kuti mbrojtëse ABS.','Kuti ABS për të mbyllur qarkun tuaj.','Instalime finale','Materiali: ABS; Përmasa: 100x60x25mm', ARRAY['enclosure'], 450.00, 0)
) AS v(name, slug, sku, cat_slug, short_desc, full_desc, apps, specs, tags, price, stock)
JOIN public.categories c ON c.slug = v.cat_slug;

-- SEED PROJECTS
INSERT INTO public.projects (title, slug, summary, description, difficulty, components) VALUES
 ('Stacion Moti me ESP32','stacion-moti-esp32','Mat temperaturën dhe lagështinë dhe shfaqi online.','Ndërto një stacion moti që lexon DHT22 me ESP32 dhe publikon të dhënat në internet me një ndërfaqe web.','Mesatar','ESP32 DevKit V1, Sensor DHT22, Ekran OLED 0.96 inç, Breadboard, Kabllo jumper'),
 ('Robot Ndjekës Vije','robot-ndjekes-vije','Robot që ndjek një vijë të zezë në dysheme.','Projekt klasik robotike me shasi 2WD, drejtues L298N dhe modul me 5 sensorë IR.','Fillestar','Shasi Robot 2WD, Drejtues L298N, Sensor Ndjekës Vije 5 Kanale, Arduino UNO, Bateri'),
 ('Sistem Ujitjeje Automatike','ujitje-automatike','Ujit bimët sipas lagështisë së tokës.','Sensori i lagështisë së tokës aktivizon një pompë përmes reles kur toka thahet.','Fillestar','Arduino UNO, Sensor Lagështie Toke, Modul Rele 1 Kanal, Pompë 5V'),
 ('Bllokim Dere me RFID','bllokim-rfid','Hap derën vetëm me kartë të autorizuar.','Lexuesi RC522 verifikon kartën dhe servoja hap bllokuesin.','Mesatar','Arduino UNO, Modul RFID RC522, Motor Servo SG90, Ekran LCD 16x2'),
 ('Alarm Tymi dhe Gazi','alarm-tymi','Sinjalizon praninë e tymit ose gazit.','MQ-2 mat nivelin e gazit dhe aktivizon sirenën dhe një njoftim SMS.','Mesatar','Arduino UNO, Sensor Gazi MQ-2, Modul GSM SIM800L, Buzzer'),
 ('Kamera Sigurie me ESP32-CAM','kamera-esp32cam','Transmeto video live në rrjetin tuaj.','ESP32-CAM krijon një server web me pamje live dhe ruajtje në microSD.','I avancuar','ESP32-CAM, Ushqyes 5V, Kabllo FTDI');