import { CircuitBoard } from "lucide-react";
import { useEffect, useState } from "react";

import { cn } from "@/lib/utils";

export function ProductImage({
  src,
  alt,
  className,
}: {
  src?: string | null | undefined;
  alt: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  const showImage = Boolean(src) && !failed;

  return (
    <div
      className={cn(
        "relative flex items-center justify-center overflow-hidden rounded-lg bg-surface circuit-dots",
        className,
      )}
    >
      {showImage ? (
        <img
          src={src as string}
          alt={alt}
          loading="lazy"
          onError={() => setFailed(true)}
          className="size-full bg-white object-contain p-2"
        />
      ) : (
        <div className="flex flex-col items-center gap-2 px-3 text-center text-muted-foreground">
          <CircuitBoard className="size-10 opacity-60" />
          <span className="text-[11px] uppercase tracking-wide">Foto do të shtohet nga Admini</span>
          <span className="line-clamp-2 text-[11px] text-foreground/70">{alt}</span>
        </div>
      )}
    </div>
  );
}
