import { Link } from "@tanstack/react-router";
import { MessageSquareText, ShoppingCart } from "lucide-react";

import { ProductImage } from "@/components/ProductImage";
import { StockBadge } from "@/components/StockBadge";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { formatPrice, type Product } from "@/lib/types";

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const outOfStock = product.stock_quantity <= 0;

  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-all hover:border-primary/50 hover:shadow-glow">
      <Link to="/products/$slug" params={{ slug: product.slug }} className="block">
        <ProductImage src={product.image_url} alt={product.name} className="aspect-4/3 w-full" />
      </Link>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <Link
            to="/products/$slug"
            params={{ slug: product.slug }}
            className="font-display text-sm font-semibold leading-snug text-card-foreground transition-colors hover:text-primary"
          >
            {product.name}
          </Link>
          {product.categories?.name ? (
            <span className="shrink-0 rounded-md bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
              {product.categories.name}
            </span>
          ) : null}
        </div>

        <p className="line-clamp-2 text-xs text-muted-foreground">{product.short_description}</p>

        <div className="mt-auto flex items-center justify-between gap-2 pt-1">
          <span className="font-mono text-base font-semibold text-primary">
            {formatPrice(product.price)}
          </span>
          <StockBadge quantity={product.stock_quantity} />
        </div>

        <div className="flex gap-2">
          <Button
            size="sm"
            className="flex-1"
            disabled={outOfStock || addItem.isPending}
            onClick={() => addItem.mutate({ productId: product.id })}
          >
            <ShoppingCart className="size-4" />
            {outOfStock ? "Pa stok" : "Shto"}
          </Button>
          <Button asChild size="sm" variant="outline">
            <Link to="/assistant" search={{ product: product.slug }}>
              <MessageSquareText className="size-4" />
              <span className="sr-only">Pyet AI</span>
            </Link>
          </Button>
        </div>
      </div>
    </article>
  );
}
