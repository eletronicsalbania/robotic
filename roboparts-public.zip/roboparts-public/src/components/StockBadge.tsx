import { cn } from "@/lib/utils";

export function StockBadge({
  quantity,
  showCount = false,
  className,
}: {
  quantity: number;
  showCount?: boolean;
  className?: string;
}) {
  const inStock = quantity > 0;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        inStock
          ? "bg-success/15 text-success"
          : "bg-destructive/15 text-destructive",
        className,
      )}
    >
      <span
        className={cn(
          "size-2 rounded-full",
          inStock ? "bg-success animate-pulse" : "bg-destructive",
        )}
      />
      {inStock ? "Në gjendje" : "Out of stock"}
      {inStock && showCount ? ` · ${quantity} copë` : ""}
    </span>
  );
}
