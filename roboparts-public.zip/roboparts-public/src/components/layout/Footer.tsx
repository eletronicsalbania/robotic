import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Facebook, Instagram, Mail, MapPin, Phone, Youtube } from "lucide-react";

import { categoriesQuery, settingsQuery } from "@/lib/api";

export function Footer() {
  const { data: settings } = useQuery(settingsQuery);
  const { data: categories } = useQuery(categoriesQuery);

  return (
    <footer className="mt-16 border-t border-border bg-surface">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <h3 className="font-display text-sm font-bold">
            {settings?.site_name ?? "eleteonicenginercomponents"}
          </h3>
          <p className="mt-3 text-sm text-muted-foreground">
            Komponentë elektronikë dhe kite prototipimi për studentë dhe inxhinierë.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold">Navigimi</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/products" className="hover:text-primary">Produktet</Link></li>
            <li><Link to="/projects" className="hover:text-primary">Projekte Studentore</Link></li>
            <li><Link to="/assistant" className="hover:text-primary">Asistenti AI</Link></li>
            <li><Link to="/cart" className="hover:text-primary">Shporta</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold">Kategori</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            {(categories ?? []).slice(0, 6).map((category) => (
              <li key={category.id}>
                <Link
                  to="/products"
                  search={{ category: category.slug }}
                  className="hover:text-primary"
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold">Kontakt</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            {settings?.contact_email ? (
              <li className="flex items-center gap-2">
                <Mail className="size-4" /> {settings.contact_email}
              </li>
            ) : null}
            {settings?.contact_phone ? (
              <li className="flex items-center gap-2">
                <Phone className="size-4" /> {settings.contact_phone}
              </li>
            ) : null}
            {settings?.contact_address ? (
              <li className="flex items-center gap-2">
                <MapPin className="size-4" /> {settings.contact_address}
              </li>
            ) : null}
          </ul>
          <div className="mt-4 flex gap-3 text-muted-foreground">
            {settings?.facebook_url ? (
              <a href={settings.facebook_url} target="_blank" rel="noreferrer" className="hover:text-primary">
                <Facebook className="size-5" />
              </a>
            ) : null}
            {settings?.instagram_url ? (
              <a href={settings.instagram_url} target="_blank" rel="noreferrer" className="hover:text-primary">
                <Instagram className="size-5" />
              </a>
            ) : null}
            {settings?.youtube_url ? (
              <a href={settings.youtube_url} target="_blank" rel="noreferrer" className="hover:text-primary">
                <Youtube className="size-5" />
              </a>
            ) : null}
          </div>
        </div>
      </div>

      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {settings?.site_name ?? "eleteonicenginercomponents"} · Të gjitha të drejtat e rezervuara
      </div>
    </footer>
  );
}
