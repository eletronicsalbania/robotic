import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bot,
  CircuitBoard,
  LayoutGrid,
  LogIn,
  Menu,
  Search,
  ShieldCheck,
  ShoppingCart,
  User as UserIcon,
} from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { categoriesQuery, settingsQuery } from "@/lib/api";

const NAV = [
  { to: "/products", label: "Produktet" },
  { to: "/projects", label: "Projekte Studentore" },
  { to: "/assistant", label: "Asistenti AI" },
] as const;

export function Header() {
  const navigate = useNavigate();
  const { user, isAdmin, signOut } = useAuth();
  const { count } = useCart();
  const { data: settings } = useQuery(settingsQuery);
  const { data: categories } = useQuery(categoriesQuery);
  const [term, setTerm] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    void navigate({ to: "/products", search: { q: term || undefined } });
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
        <Link to="/" className="flex shrink-0 items-center gap-2">
          {settings?.logo_url ? (
            <img src={settings.logo_url} alt="" className="size-8 rounded-md object-cover" />
          ) : (
            <span className="grid size-8 place-items-center rounded-md gradient-accent">
              <CircuitBoard className="size-5 text-primary-foreground" />
            </span>
          )}
          <span className="hidden font-display text-sm font-bold tracking-tight sm:inline">
            {settings?.site_name ?? "eleteonicenginercomponents"}
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">
                <LayoutGrid className="size-4" />
                Kategoritë
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="max-h-96 w-60 overflow-y-auto">
              {(categories ?? []).map((category) => (
                <DropdownMenuItem key={category.id} asChild>
                  <Link to="/products" search={{ category: category.slug }}>
                    {category.name}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {NAV.map((item) => (
            <Button key={item.to} variant="ghost" size="sm" asChild>
              <Link to={item.to}>{item.label}</Link>
            </Button>
          ))}
        </nav>

        <form onSubmit={submitSearch} className="ml-auto hidden max-w-xs flex-1 md:block">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={term}
              onChange={(event) => setTerm(event.target.value)}
              placeholder="Kërko komponentë..."
              className="pl-9"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link to="/cart" aria-label="Shporta">
              <ShoppingCart className="size-5" />
              {count > 0 ? (
                <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {count}
                </span>
              ) : null}
            </Link>
          </Button>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Llogaria">
                  <UserIcon className="size-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem asChild>
                  <Link to="/profile">Profili im</Link>
                </DropdownMenuItem>
                {isAdmin ? (
                  <DropdownMenuItem asChild>
                  </DropdownMenuItem>
                ) : null}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => void signOut()}>Dil</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button size="sm" asChild className="hidden sm:inline-flex">
              <Link to="/auth">
                <LogIn className="size-4" /> Hyr
              </Link>
            </Button>
          )}

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Menuja">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 overflow-y-auto">
              <SheetTitle className="px-4 pt-4 font-display">Menuja</SheetTitle>
              <div className="flex flex-col gap-1 p-4">
                <form onSubmit={submitSearch} className="mb-3">
                  <Input
                    value={term}
                    onChange={(event) => setTerm(event.target.value)}
                    placeholder="Kërko komponentë..."
                  />
                </form>
                {NAV.map((item) => (
                  <Button
                    key={item.to}
                    variant="ghost"
                    className="justify-start"
                    asChild
                    onClick={() => setMobileOpen(false)}
                  >
                    <Link to={item.to}>{item.label}</Link>
                  </Button>
                ))}
                {!user ? (
                  <Button className="mt-2" asChild onClick={() => setMobileOpen(false)}>
                    <Link to="/auth">
                      <LogIn className="size-4" /> Hyr / Regjistrohu
                    </Link>
                  </Button>
                ) : null}
                <p className="mt-4 px-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Kategoritë
                </p>
                {(categories ?? []).map((category) => (
                  <Button
                    key={category.id}
                    variant="ghost"
                    size="sm"
                    className="justify-start"
                    asChild
                    onClick={() => setMobileOpen(false)}
                  >
                    <Link to="/products" search={{ category: category.slug }}>
                      {category.name}
                    </Link>
                  </Button>
                ))}
                <Button variant="outline" className="mt-4" asChild onClick={() => setMobileOpen(false)}>
                  <Link to="/assistant">
                    <Bot className="size-4" /> Asistenti AI
                  </Link>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
