export type PurchaseStatus = "Pending" | "Confirmed" | "Preparing" | "Completed" | "Cancelled";

export const PURCHASE_STATUSES: PurchaseStatus[] = [
  "Pending",
  "Confirmed",
  "Preparing",
  "Completed",
  "Cancelled",
];

export const STATUS_LABELS: Record<PurchaseStatus, string> = {
  Pending: "Në pritje",
  Confirmed: "Konfirmuar",
  Preparing: "Në përgatitje",
  Completed: "Përfunduar",
  Cancelled: "Anuluar",
};

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  sort_order: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  sku: string | null;
  category_id: string | null;
  short_description: string | null;
  full_description: string | null;
  applications: string | null;
  specifications: string | null;
  tags: string[];
  price: number;
  stock_quantity: number;
  image_url: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  categories?: { name: string; slug: string } | null;
}

export interface StudentProject {
  id: string;
  title: string;
  slug: string;
  summary: string | null;
  description: string | null;
  difficulty: string;
  components: string | null;
  image_url: string | null;
  is_published: boolean;
}

export interface CartItem {
  id: string;
  cart_id: string;
  product_id: string;
  quantity: number;
  products: Product | null;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  sender: "user" | "ai" | "admin";
  content: string;
  created_at: string;
}

export interface Conversation {
  id: string;
  user_id: string | null;
  title: string;
  admin_takeover: boolean;
  is_open: boolean;
  created_at: string;
  updated_at: string;
}

export interface PurchaseRequest {
  id: string;
  user_id: string;
  conversation_id: string | null;
  status: PurchaseStatus;
  total_amount: number;
  contact_name: string | null;
  contact_phone: string | null;
  notes: string | null;
  admin_note: string | null;
  created_at: string;
}

export interface WebsiteSettings {
  id: number;
  site_name: string;
  logo_url: string | null;
  hero_title: string;
  hero_subtitle: string;
  contact_email: string | null;
  contact_phone: string | null;
  contact_address: string | null;
  facebook_url: string | null;
  instagram_url: string | null;
  tiktok_url: string | null;
  youtube_url: string | null;
}

export interface AiSettings {
  id: number;
  enabled: boolean;
  model: string;
  system_prompt: string;
  welcome_message: string;
}

export function formatPrice(value: number | string | null | undefined) {
  const n = Number(value ?? 0);
  return `${n.toLocaleString("sq-AL", { minimumFractionDigits: 0, maximumFractionDigits: 2 })} L`;
}
