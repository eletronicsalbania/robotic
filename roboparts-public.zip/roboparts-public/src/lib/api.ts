import { supabase } from "@/integrations/supabase/client";
import type {
  AiSettings,
  Category,
  Product,
  StudentProject,
  WebsiteSettings,
} from "@/lib/types";

export const settingsQuery = {
  queryKey: ["website_settings"],
  queryFn: async (): Promise<WebsiteSettings | null> => {
    const { data, error } = await supabase.from("website_settings").select("*").eq("id", 1).maybeSingle();
    if (error) throw error;
    return data as WebsiteSettings | null;
  },
};

export const aiSettingsQuery = {
  queryKey: ["ai_settings"],
  queryFn: async (): Promise<AiSettings | null> => {
    const { data, error } = await supabase.from("ai_settings").select("*").eq("id", 1).maybeSingle();
    if (error) throw error;
    return data as AiSettings | null;
  },
};

export const categoriesQuery = {
  queryKey: ["categories"],
  queryFn: async (): Promise<Category[]> => {
    const { data, error } = await supabase
      .from("categories")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return (data ?? []) as Category[];
  },
};

export function productsQuery(options?: { categorySlug?: string; includeInactive?: boolean }) {
  return {
    queryKey: ["products", options?.categorySlug ?? "all", options?.includeInactive ?? false],
    queryFn: async (): Promise<Product[]> => {
      let q = supabase
        .from("products")
        .select("*, categories(name, slug)")
        .order("created_at", { ascending: false });
      if (!options?.includeInactive) q = q.eq("is_active", true);
      const { data, error } = await q;
      if (error) throw error;
      let rows = (data ?? []) as unknown as Product[];
      if (options?.categorySlug) {
        rows = rows.filter((p) => p.categories?.slug === options.categorySlug);
      }
      return rows;
    },
  };
}

export function productBySlugQuery(slug: string) {
  return {
    queryKey: ["product", slug],
    queryFn: async (): Promise<Product | null> => {
      const { data, error } = await supabase
        .from("products")
        .select("*, categories(name, slug)")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as Product | null;
    },
  };
}

export const projectsQuery = {
  queryKey: ["projects"],
  queryFn: async (): Promise<StudentProject[]> => {
    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as StudentProject[];
  },
};
