import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const AI_API_URL =
  process.env["AI_API_URL"] || "https://api.openai.com/v1/chat/completions";
const AI_API_KEY = process.env["AI_API_KEY"];
const AI_MODEL = process.env["AI_MODEL"] || "gpt-5.6";

export interface ChatReply {
  conversationId: string;
  reply: string | null;
  status: "ok" | "takeover" | "disabled" | "not-configured" | "error";
  message?: string;
  purchaseRequestId?: string | undefined;
}

const InputSchema = z.object({
  conversationId: z.string().uuid().nullable().optional(),
  message: z.string().min(1).max(4000),
});

interface CatalogRow {
  name: string;
  sku: string | null;
  slug: string;
  price: number;
  stock_quantity: number;
  short_description: string | null;
  applications: string | null;
  categories: { name: string } | null;
}

function catalogToText(rows: CatalogRow[]) {
  return rows
    .map(
      (p) =>
        `- ${p.name} | SKU: ${p.sku ?? "-"} | Kategoria: ${p.categories?.name ?? "-"} | Çmimi: ${Number(
          p.price,
        )} L | Stoku: ${p.stock_quantity} ${p.stock_quantity > 0 ? "(Në gjendje)" : "(Out of stock)"} | ${
          p.short_description ?? ""
        }${p.applications ? ` | Përdorimet: ${p.applications}` : ""}`,
    )
    .join("\n");
}

const purchaseTool = {
  type: "function" as const,
  function: {
    name: "krijo_kerkese_blerje",
    description:
      "Krijon një kërkesë blerjeje kur përdoruesi konfirmon se dëshiron t'i blejë produktet. Përdore vetëm kur përdoruesi e kërkon qartë blerjen.",
    parameters: {
      type: "object",
      additionalProperties: false,
      properties: {
        items: {
          type: "array",
          description: "Produktet që do të blihen",
          items: {
            type: "object",
            additionalProperties: false,
            properties: {
              sku: { type: "string", description: "SKU e produktit nga katalogu" },
              quantity: { type: "number", description: "Sasia e kërkuar" },
            },
            required: ["sku", "quantity"],
          },
        },
        note: { type: "string", description: "Shënim opsional nga përdoruesi" },
      },
      required: ["items", "note"],
    },
  },
};

export const sendChatMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data, context }): Promise<ChatReply> => {
    const supabase = context.supabase;
    const userId = context.userId;

    // 1. Resolve conversation (owned by this user)
    let conversationId = data.conversationId ?? null;
    if (conversationId) {
      const { data: conv } = await supabase
        .from("chat_conversations")
        .select("id")
        .eq("id", conversationId)
        .maybeSingle();
      if (!conv) conversationId = null;
    }
    if (!conversationId) {
      const { data: created, error } = await supabase
        .from("chat_conversations")
        .insert({ user_id: userId, title: data.message.slice(0, 60) })
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      conversationId = created.id;
    }

    // 2. Store the user message
    await supabase
      .from("chat_messages")
      .insert({ conversation_id: conversationId, sender: "user", content: data.message });
    await supabase
      .from("chat_conversations")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", conversationId);

    const { data: conversation } = await supabase
      .from("chat_conversations")
      .select("admin_takeover")
      .eq("id", conversationId)
      .maybeSingle();

    await supabase.from("notifications").insert({
      type: "chat",
      title: "Mesazh i ri në chat",
      body: data.message.slice(0, 160),
      related_id: conversationId,
      link: `/assistant?conversation=${conversationId}`,
    });

    if (conversation?.admin_takeover) {
      return { conversationId, reply: null, status: "takeover" };
    }

    // 3. AI settings + credentials
    const { data: aiSettings } = await supabase
      .from("ai_settings")
      .select("enabled, model, system_prompt")
      .eq("id", 1)
      .maybeSingle();

    if (aiSettings && aiSettings.enabled === false) {
      return { conversationId, reply: null, status: "disabled" };
    }

    const apiKey = AI_API_KEY;
    if (!apiKey) {
      return {
        conversationId,
        reply: null,
        status: "not-configured",
        message: "Asistenti AI nuk është konfiguruar ende (mungon çelësi i shërbimit AI).",
      };
    }

    // 4. Live catalogue straight from the database
    const { data: catalog } = await supabase
      .from("products")
      .select("name, sku, slug, price, stock_quantity, short_description, applications, categories(name)")
      .eq("is_active", true)
      .order("name");

    const { data: history } = await supabase
      .from("chat_messages")
      .select("sender, content")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })
      .limit(40);

    const model = aiSettings?.model || AI_MODEL;
    const systemPrompt = `${aiSettings?.system_prompt ?? "Ti je asistenti i dyqanit të komponentëve elektronikë."}

Rregulla:
- Përgjigju gjithmonë në shqip, shkurt dhe qartë.
- Përdor VETËM të dhënat e katalogut më poshtë për emra, çmime dhe gjendje stoku. Mos shpik produkte apo çmime.
- Nëse një produkt është Out of stock, thuaje hapur dhe sugjero alternativa nga katalogu.
- Kur përdoruesi përshkruan një projekt, ndërto listë komponentësh me sasi dhe totalin e çmimit.
- Krijo kërkesë blerjeje vetëm kur përdoruesi konfirmon se dëshiron të blejë.

KATALOGU AKTUAL (gjendja reale):
${catalogToText((catalog ?? []) as unknown as CatalogRow[])}`;

    const messages: Array<Record<string, unknown>> = [
      { role: "system", content: systemPrompt },
      ...(history ?? []).map((m) => ({
        role: m.sender === "user" ? "user" : "assistant",
        content: m.content,
      })),
    ];

    const body: Record<string, unknown> = { model, messages, tools: [purchaseTool] };
    if (model.startsWith("openai/gpt-5.6")) body["reasoning_effort"] = "none";

    const callGateway = async (payload: Record<string, unknown>) =>
      fetch(AI_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify(payload),
      });

    let purchaseRequestId: string | undefined;

    try {
      let response = await callGateway(body);
      if (response.status === 429) {
        return {
          conversationId,
          reply: null,
          status: "error",
          message: "Shumë kërkesa njëherësh. Provoni sërish pas pak.",
        };
      }
      if (response.status === 402) {
        return {
          conversationId,
          reply: null,
          status: "not-configured",
          message: "Kredia e shërbimit AI ka mbaruar. Administratori duhet ta rimbushë.",
        };
      }
      if (!response.ok) {
        return {
          conversationId,
          reply: null,
          status: "error",
          message: `Shërbimi AI ktheu gabim (${response.status}).`,
        };
      }

      let json = (await response.json()) as {
        choices?: Array<{
          message?: {
            content?: string | null;
            tool_calls?: Array<{ id: string; function: { name: string; arguments: string } }>;
          };
        }>;
      };
      let choice = json.choices?.[0]?.message;

      // 5. Handle purchase-request tool call
      const toolCall = choice?.tool_calls?.[0];
      if (toolCall && toolCall.function.name === "krijo_kerkese_blerje") {
        const args = JSON.parse(toolCall.function.arguments || "{}") as {
          items?: Array<{ sku: string; quantity: number }>;
          note?: string;
        };
        const skus = (args.items ?? []).map((item) => item.sku);
        const { data: matched } = await supabase
          .from("products")
          .select("id, name, sku, price, stock_quantity")
          .in("sku", skus.length ? skus : ["__none__"]);

        const rows = (args.items ?? [])
          .map((item) => {
            const product = (matched ?? []).find((p) => p.sku === item.sku);
            if (!product) return null;
            return {
              product,
              quantity: Math.max(1, Math.round(item.quantity || 1)),
            };
          })
          .filter(Boolean) as Array<{
          product: { id: string; name: string; price: number; stock_quantity: number };
          quantity: number;
        }>;

        let toolResult: string;
        if (rows.length === 0) {
          toolResult = "Nuk u gjet asnjë produkt me këto SKU. Kërkesa nuk u krijua.";
        } else {
          const total = rows.reduce((sum, r) => sum + Number(r.product.price) * r.quantity, 0);
          const { data: request, error } = await supabase
            .from("purchase_requests")
            .insert({
              user_id: userId,
              conversation_id: conversationId,
              total_amount: total,
              notes: args.note ?? null,
              status: "Pending",
            })
            .select("id")
            .single();
          if (error) {
            toolResult = "Kërkesa nuk u krijua për shkak të një gabimi teknik.";
          } else {
            purchaseRequestId = request.id;
            await supabase.from("purchase_request_items").insert(
              rows.map((r) => ({
                request_id: request.id,
                product_id: r.product.id,
                product_name: r.product.name,
                unit_price: r.product.price,
                quantity: r.quantity,
              })),
            );
            await supabase.from("notifications").insert({
              type: "purchase_request",
              title: "Kërkesë e re blerjeje (nga AI)",
              body: `${rows.length} produkte · Totali ${total} L`,
              related_id: request.id,
              link: "/profile",
            });
            toolResult = `Kërkesa u krijua me sukses. Statusi: Pending. Totali: ${total} L. Produktet: ${rows
              .map((r) => `${r.product.name} x${r.quantity}`)
              .join(", ")}. Nuk është kryer asnjë pagesë — administratori do t'ju kontaktojë.`;
          }
        }

        messages.push({
          role: "assistant",
          content: choice?.content ?? "",
          tool_calls: choice?.tool_calls,
        });
        messages.push({ role: "tool", tool_call_id: toolCall.id, content: toolResult });

        response = await callGateway({ ...body, messages, tools: [purchaseTool] });
        if (response.ok) {
          json = await response.json();
          choice = json.choices?.[0]?.message;
        } else {
          choice = { content: toolResult };
        }
      }

      const reply = (choice?.content ?? "").trim() || "Nuk munda të gjeneroj përgjigje.";
      await supabase
        .from("chat_messages")
        .insert({ conversation_id: conversationId, sender: "ai", content: reply });

      return { conversationId, reply, status: "ok", purchaseRequestId };
    } catch (error) {
      console.error("AI chat error", error);
      return {
        conversationId,
        reply: null,
        status: "error",
        message: "Ndodhi një gabim gjatë komunikimit me asistentin.",
      };
    }
  });

export const getAiStatus = createServerFn({ method: "GET" }).handler(async () => ({
  configured: Boolean(AI_API_KEY),
}));
