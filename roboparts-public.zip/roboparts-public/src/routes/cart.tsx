import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { ProductImage } from "@/components/ProductImage";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { StockBadge } from "@/components/StockBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/types";

export const Route = createFileRoute("/cart")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Shporta — eleteonicenginercomponents" },
      {
        name: "description",
        content: "Shiko produktet në shportë, kontrollo gjendjen e stokut dhe dërgo kërkesë blerjeje.",
      },
      { property: "og:title", content: "Shporta" },
      { property: "og:description", content: "Dërgo kërkesën tënde të blerjes pa pagesë online." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { items, total, updateQuantity, removeItem, clearCart } = useCart();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const invalid = items.filter(
    (item) => !item.products || item.products.stock_quantity < item.quantity,
  );

  const submitRequest = async () => {
    if (!user) return;
    if (items.length === 0) return;
    if (invalid.length > 0) {
      toast.error("Disa produkte nuk kanë stok të mjaftueshëm. Rregulloni sasitë.");
      return;
    }
    if (!name.trim() || phone.trim().length < 6) {
      toast.error("Plotësoni emrin dhe numrin e telefonit që të mund t'ju kontaktojmë.");
      return;
    }
    setSubmitting(true);
    try {
      const { data: conversation } = await supabase
        .from("chat_conversations")
        .insert({ user_id: user.id, title: "Kërkesë blerjeje" })
        .select("id")
        .single();

      const { data: request, error } = await supabase
        .from("purchase_requests")
        .insert({
          user_id: user.id,
          conversation_id: conversation?.id ?? null,
          total_amount: total,
          contact_name: name || null,
          contact_phone: phone || null,
          notes: notes || null,
          status: "Pending",
        })
        .select("id")
        .single();
      if (error) throw error;

      const { error: itemsError } = await supabase.from("purchase_request_items").insert(
        items.map((item) => ({
          request_id: request.id,
          product_id: item.product_id,
          product_name: item.products?.name ?? "Produkt",
          unit_price: item.products?.price ?? 0,
          quantity: item.quantity,
        })),
      );
      if (itemsError) throw itemsError;

      await supabase.from("notifications").insert({
        type: "purchase_request",
        title: "Kërkesë e re blerjeje",
        body: `${items.length} produkte · Totali ${formatPrice(total)}`,
        related_id: request.id,
        link: "/profile",
      });

      if (conversation?.id) {
        await supabase.from("chat_messages").insert({
          conversation_id: conversation.id,
          sender: "user",
          content: `Kërkesë blerjeje e dërguar:\n${items
            .map((item) => `• ${item.products?.name} x${item.quantity}`)
            .join("\n")}\nTotali: ${formatPrice(total)}`,
        });
      }

      await clearCart.mutateAsync();
      toast.success("Kërkesa u dërgua! Nuk është kryer asnjë pagesë — do t'ju kontaktojmë.");
      void navigate({ to: "/profile" });
    } catch {
      toast.error("Kërkesa nuk u dërgua. Provoni përsëri.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <SiteLayout>
        <div className="mx-auto max-w-lg px-4 py-24 text-center">
          <ShoppingBag className="mx-auto size-10 text-muted-foreground" />
          <h1 className="mt-4 font-display text-2xl font-bold">Shporta juaj</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Hyni në llogari për të parë dhe ruajtur shportën tuaj.
          </p>
          <Button className="mt-6" asChild>
            <Link to="/auth">Hyr në llogari</Link>
          </Button>
        </div>
      </SiteLayout>
    );
  }

  return (
    <SiteLayout>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Shporta</h1>

        {items.length === 0 ? (
          <div className="mt-10 rounded-xl border border-dashed border-border p-12 text-center">
            <p className="font-display text-lg font-semibold">Shporta është bosh</p>
            <Button className="mt-5" asChild>
              <Link to="/products">Shfleto produktet</Link>
            </Button>
          </div>
        ) : (
          <div className="mt-8 grid gap-8 lg:grid-cols-3">
            <div className="space-y-3 lg:col-span-2">
              {items.map((item) => {
                const stock = item.products?.stock_quantity ?? 0;
                const exceeds = item.quantity > stock;
                return (
                  <div
                    key={item.id}
                    className="flex gap-4 rounded-xl border border-border bg-card p-4"
                  >
                    <ProductImage
                      src={item.products?.image_url}
                      alt={item.products?.name ?? ""}
                      className="size-24 shrink-0"
                    />
                    <div className="flex flex-1 flex-col gap-2">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold">{item.products?.name}</p>
                          <p className="font-mono text-sm text-primary">
                            {formatPrice(item.products?.price)}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem.mutate(item.id)}
                          aria-label="Hiq"
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap items-center gap-3">
                        <div className="flex items-center rounded-md border border-border">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() =>
                              updateQuantity.mutate({ itemId: item.id, quantity: item.quantity - 1 })
                            }
                          >
                            <Minus className="size-3.5" />
                          </Button>
                          <span className="w-10 text-center font-mono text-sm">{item.quantity}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            disabled={item.quantity >= stock}
                            onClick={() =>
                              updateQuantity.mutate({ itemId: item.id, quantity: item.quantity + 1 })
                            }
                          >
                            <Plus className="size-3.5" />
                          </Button>
                        </div>
                        <StockBadge quantity={stock} showCount />
                        {exceeds ? (
                          <span className="text-xs text-destructive">
                            Stoku i mjaftueshëm mungon
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="h-fit rounded-xl border border-border bg-card p-5">
              <h2 className="font-display text-lg font-semibold">Kërkesë blerjeje</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                Nuk kryhet asnjë pagesë online. Ne ju kontaktojmë për konfirmim.
              </p>

              <div className="mt-4 space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Emri</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">Telefoni</Label>
                  <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="notes">Shënime</Label>
                  <Textarea id="notes" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
                <span className="text-sm text-muted-foreground">Totali</span>
                <span className="font-mono text-xl font-bold text-primary">{formatPrice(total)}</span>
              </div>

              <Button
                className="mt-4 w-full"
                size="lg"
                disabled={submitting || invalid.length > 0}
                onClick={() => void submitRequest()}
              >
                Dërgo kërkesën
              </Button>
            </div>
          </div>
        )}
      </div>
    </SiteLayout>
  );
}
