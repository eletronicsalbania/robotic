import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice, STATUS_LABELS, type PurchaseStatus } from "@/lib/types";

export const Route = createFileRoute("/profile")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Profili im — eleteonicenginercomponents" },
      { name: "description", content: "Menaxho të dhënat e llogarisë dhe shiko kërkesat e tua të blerjes." },
      { property: "og:title", content: "Profili im" },
      { property: "og:description", content: "Të dhënat e llogarisë dhe historiku i kërkesave." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const profile = useQuery({
    queryKey: ["profile", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      return data;
    },
  });

  const requests = useQuery({
    queryKey: ["my-requests", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data } = await supabase
        .from("purchase_requests")
        .select("*, purchase_request_items(*)")
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  useEffect(() => {
    if (profile.data) {
      setFullName(profile.data.full_name ?? "");
      setPhone(profile.data.phone ?? "");
      setAddress(profile.data.address ?? "");
    }
  }, [profile.data]);

  if (!user) {
    return (
      <SiteLayout>
        <div className="mx-auto max-w-md px-4 py-24 text-center">
          <h1 className="font-display text-2xl font-bold">Profili</h1>
          <p className="mt-2 text-sm text-muted-foreground">Hyni për të parë profilin tuaj.</p>
          <Button className="mt-6" asChild>
            <Link to="/auth">Hyr</Link>
          </Button>
        </div>
      </SiteLayout>
    );
  }

  const save = async () => {
    const { error } = await supabase
      .from("profiles")
      .upsert({ id: user.id, email: user.email ?? null, full_name: fullName, phone, address });
    if (error) {
      toast.error("Ruajtja dështoi");
      return;
    }
    toast.success("Të dhënat u ruajtën");
    void queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
  };

  return (
    <SiteLayout>
      <div className="mx-auto max-w-5xl px-4 py-10">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="font-display text-3xl font-bold">Profili im</h1>
          {isAdmin ? (
            <Button variant="outline" asChild>
