import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, MessageSquareText, ShoppingCart } from "lucide-react";

import { ProductCard } from "@/components/ProductCard";
import { ProductImage } from "@/components/ProductImage";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { StockBadge } from "@/components/StockBadge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useCart } from "@/hooks/useCart";
import { productBySlugQuery, productsQuery } from "@/lib/api";
import { formatPrice } from "@/lib/types";

export const Route = createFileRoute("/products/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} — eleteonicenginercomponents` },
      {
        name: "description",
        content: "Detajet e produktit: përshkrim, aplikime, specifikime, çmim dhe gjendje stoku.",
      },
      { property: "og:title", content: "Detajet e produktit" },
      {
        property: "og:description",
        content: "Shiko specifikimet, aplikimet dhe gjendjen aktuale të stokut.",
      },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductDetail,
});

function ProductDetail() {
  const { slug } = Route.useParams();
  const { data: product, isLoading } = useQuery(productBySlugQuery(slug));
  const { data: allProducts } = useQuery(productsQuery());
  const { addItem } = useCart();

  if (isLoading) {
    return (
      <SiteLayout>
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 lg:grid-cols-2">
          <Skeleton className="aspect-4/3 rounded-xl" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-2/3" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-10 w-1/3" />
          </div>
        </div>
      </SiteLayout>
    );
  }

  if (!product) {
    return (
      <SiteLayout>
        <div className="mx-auto max-w-xl px-4 py-24 text-center">
          <h1 className="font-display text-2xl font-bold">Produkti nuk u gjet</h1>
          <Button className="mt-6" asChild>
            <Link to="/products">Kthehu te produktet</Link>
          </Button>
        </div>
      </SiteLayout>
    );
  }

  const related = (allProducts ?? [])
    .filter((p) => p.category_id === product.category_id && p.id !== product.id)
    .slice(0, 4);

  const specs = (product.specifications ?? "")
    .split(/;|\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-7xl px-4 py-8">
        <Button variant="ghost" size="sm" asChild className="mb-6">
          <Link to="/products">
            <ArrowLeft className="size-4" /> Të gjitha produktet
          </Link>
        </Button>

        <div className="grid gap-10 lg:grid-cols-2">
          <ProductImage
            src={product.image_url}
            alt={product.name}
            className="aspect-4/3 w-full border border-border"
          />

          <div>
            {product.categories?.name ? (
              <Link
                to="/products"
                search={{ category: product.categories.slug }}
                className="text-xs uppercase tracking-wide text-primary"
              >
                {product.categories.name}
              </Link>
            ) : null}
            <h1 className="mt-2 font-display text-3xl font-bold">{product.name}</h1>
            {product.sku ? (
              <p className="mt-1 font-mono text-xs text-muted-foreground">SKU: {product.sku}</p>
            ) : null}

            <p className="mt-4 text-sm text-muted-foreground">{product.short_description}</p>

            <div className="mt-6 flex flex-wrap items-center gap-4">
              <span className="font-mono text-3xl font-bold text-primary">
                {formatPrice(product.price)}
              </span>
              <StockBadge quantity={product.stock_quantity} showCount />
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Button
                size="lg"
                disabled={product.stock_quantity <= 0 || addItem.isPending}
                onClick={() => addItem.mutate({ productId: product.id })}
              >
                <ShoppingCart className="size-4" />
                {product.stock_quantity > 0 ? "Shto në shportë" : "Out of stock"}
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/assistant" search={{ product: product.slug }}>
                  <MessageSquareText className="size-4" /> Pyet AI për këtë produkt
                </Link>
              </Button>
            </div>

            {product.tags.length > 0 ? (
              <div className="mt-6 flex flex-wrap gap-2">
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-md bg-secondary px-2 py-1 text-[11px] text-muted-foreground"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          <section className="rounded-xl border border-border bg-card p-6 lg:col-span-2">
            <h2 className="font-display text-lg font-semibold">Përshkrimi</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {product.full_description || product.short_description || "Përshkrimi do të shtohet së shpejti."}
            </p>

            {product.applications ? (
              <>
                <h3 className="mt-8 font-display text-base font-semibold">Përdorimet / Aplikimet</h3>
                <p className="mt-2 whitespace-pre-line text-sm text-muted-foreground">
                  {product.applications}
                </p>
              </>
            ) : null}
          </section>

          <section className="rounded-xl border border-border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Specifikimet</h2>
            {specs.length > 0 ? (
              <dl className="mt-3 space-y-2 text-sm">
                {specs.map((spec) => {
                  const [key, ...rest] = spec.split(":");
                  const value = rest.join(":").trim();
                  return (
                    <div key={spec} className="flex justify-between gap-4 border-b border-border pb-2">
                      <dt className="text-muted-foreground">{key}</dt>
                      <dd className="text-right font-medium">{value || "—"}</dd>
                    </div>
                  );
                })}
              </dl>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">Nuk ka specifikime të regjistruara.</p>
            )}
          </section>
        </div>

        {related.length > 0 ? (
          <section className="mt-14">
            <h2 className="font-display text-xl font-bold">Produkte të ngjashme</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((item) => (
                <ProductCard key={item.id} product={item} />
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </SiteLayout>
  );
}
