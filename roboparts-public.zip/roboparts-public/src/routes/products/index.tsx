import { useQuery } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Search, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";

import { ProductCard } from "@/components/ProductCard";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { categoriesQuery, productsQuery } from "@/lib/api";

type StockFilter = "all" | "in" | "out";

interface ProductSearch {
  q?: string | undefined;
  category?: string | undefined;
  stock?: StockFilter | undefined;
}

export const Route = createFileRoute("/products/")({
  validateSearch: (search: Record<string, unknown>): ProductSearch => ({
    q: typeof search["q"] === "string" && search["q"] ? search["q"] : undefined,
    category:
      typeof search["category"] === "string" && search["category"] ? search["category"] : undefined,
    stock:
      search["stock"] === "in" || search["stock"] === "out" ? (search["stock"] as StockFilter) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Produktet — eleteonicenginercomponents" },
      {
        name: "description",
        content:
          "Katalogu i plotë i komponentëve elektronikë me filtra sipas kategorisë, kërkimit dhe gjendjes në stok.",
      },
      { property: "og:title", content: "Katalogu i produkteve" },
      {
        property: "og:description",
        content: "Arduino, ESP32, sensorë, ekrane, motorë, rele dhe module komunikimi.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/products/" });
  const { data: categories } = useQuery(categoriesQuery);
  const { data: products, isLoading } = useQuery(productsQuery());
  const [term, setTerm] = useState(search["q"] ?? "");

  const filtered = useMemo(() => {
    const q = (search["q"] ?? "").toLowerCase().trim();
    return (products ?? []).filter((product) => {
      if (search["category"] && product.categories?.slug !== search["category"]) return false;
      if (search["stock"] === "in" && product.stock_quantity <= 0) return false;
      if (search["stock"] === "out" && product.stock_quantity > 0) return false;
      if (!q) return true;
      return [
        product.name,
        product.sku ?? "",
        product.short_description ?? "",
        product.full_description ?? "",
        product.tags.join(" "),
      ]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [products, search]);

  const update = (patch: Partial<ProductSearch>) => {
    void navigate({ search: ((prev: ProductSearch) => ({ ...prev, ...patch })) as never });
  };

  return (
    <SiteLayout>
      <div className="mx-auto max-w-7xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Produktet</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {filtered.length} produkte të disponueshme në katalog
        </p>

        <div className="mt-6 flex flex-col gap-3 rounded-xl border border-border bg-card p-4 md:flex-row md:items-center">
          <form
            className="relative flex-1"
            onSubmit={(event) => {
              event.preventDefault();
              update({ q: term || undefined });
            }}
          >
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={term}
              onChange={(event) => setTerm(event.target.value)}
              placeholder="Kërko sipas emrit, SKU ose përshkrimit..."
              className="pl-9"
            />
          </form>

          <Select
            value={search["category"] ?? "all"}
            onValueChange={(value) => update({ category: value === "all" ? undefined : value })}
          >
            <SelectTrigger className="md:w-56">
              <SelectValue placeholder="Kategoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Të gjitha kategoritë</SelectItem>
              {(categories ?? []).map((category) => (
                <SelectItem key={category.id} value={category.slug}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={search["stock"] ?? "all"}
            onValueChange={(value) =>
              update({ stock: value === "all" ? undefined : (value as StockFilter) })
            }
          >
            <SelectTrigger className="md:w-44">
              <SlidersHorizontal className="size-4" />
              <SelectValue placeholder="Gjendja" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Çdo gjendje</SelectItem>
              <SelectItem value="in">Në gjendje</SelectItem>
              <SelectItem value="out">Out of stock</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="ghost"
            onClick={() => {
              setTerm("");
              void navigate({ search: {} as never });
            }}
          >
            Pastro
          </Button>
        </div>

        {isLoading ? (
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, index) => (
              <Skeleton key={index} className="h-80 rounded-xl" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-16 rounded-xl border border-dashed border-border p-12 text-center">
            <p className="font-display text-lg font-semibold">Asnjë produkt nuk u gjet</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Provoni një kërkim tjetër ose pastroni filtrat.
            </p>
          </div>
        ) : (
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </SiteLayout>
  );
}
