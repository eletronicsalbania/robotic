import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bot, Cpu } from "lucide-react";

import { ProductImage } from "@/components/ProductImage";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { projectsQuery } from "@/lib/api";

export const Route = createFileRoute("/projects/")({
  head: () => ({
    meta: [
      { title: "Projekte Studentore — eleteonicenginercomponents" },
      {
        name: "description",
        content:
          "Ide projektesh studentore në elektronikë me listën e komponentëve të nevojshëm dhe nivelin e vështirësisë.",
      },
      { property: "og:title", content: "Projekte Studentore" },
      {
        property: "og:description",
        content: "Stacion moti, robot ndjekës vije, ujitje automatike dhe më shumë.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const { data: projects } = useQuery(projectsQuery);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-7xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Projekte Studentore</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Ide të provuara me listën e komponentëve. Zgjidh një projekt dhe pyet asistentin AI për
          listën e plotë të pjesëve.
        </p>

        <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {(projects ?? []).map((project) => (
            <article
              key={project.id}
              className="flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-colors hover:border-primary/50"
            >
              <ProductImage src={project.image_url} alt={project.title} className="aspect-16/9 w-full" />
              <div className="flex flex-1 flex-col gap-3 p-5">
                <span className="w-fit rounded-md bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                  {project.difficulty}
                </span>
                <h2 className="font-display text-base font-semibold">{project.title}</h2>
                <p className="text-sm text-muted-foreground">{project.summary}</p>
                {project.description ? (
                  <p className="text-xs leading-relaxed text-muted-foreground">{project.description}</p>
                ) : null}
                {project.components ? (
                  <div className="mt-2 rounded-lg border border-border bg-surface p-3">
                    <p className="flex items-center gap-2 text-xs font-semibold">
                      <Cpu className="size-3.5 text-primary" /> Komponentët
                    </p>
                    <p className="mt-1.5 text-xs text-muted-foreground">{project.components}</p>
                  </div>
                ) : null}
                <div className="mt-auto flex gap-2 pt-2">
                  <Button size="sm" variant="outline" asChild className="flex-1">
                    <Link to="/assistant" search={{ project: project.slug }}>
                      <Bot className="size-4" /> Pyet AI
                    </Link>
                  </Button>
                  <Button size="sm" asChild className="flex-1">
                    <Link to="/products">Gjej pjesët</Link>
                  </Button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </SiteLayout>
  );
}
