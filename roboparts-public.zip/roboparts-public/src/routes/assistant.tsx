import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { AlertTriangle, Bot, Send, User as UserIcon } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { aiSettingsQuery } from "@/lib/api";
import { sendChatMessage } from "@/lib/ai.functions";
import type { ChatMessage } from "@/lib/types";

interface AssistantSearch {
  product?: string | undefined;
  project?: string | undefined;
}

export const Route = createFileRoute("/assistant")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>): AssistantSearch => ({
    product: typeof search["product"] === "string" ? (search["product"] as string) : undefined,
    project: typeof search["project"] === "string" ? (search["project"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Asistenti AI — eleteonicenginercomponents" },
      {
        name: "description",
        content:
          "Asistenti AI të ndihmon të zgjedhësh komponentë, kontrollon stokun real dhe ndërton lista pjesësh për projektin tënd.",
      },
      { property: "og:title", content: "Asistenti AI" },
      { property: "og:description", content: "Pyet për komponentë, stok dhe alternativa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AssistantPage,
});

function AssistantPage() {
  const search = Route.useSearch();
  const { user } = useAuth();
  const { data: aiSettings } = useQuery(aiSettingsQuery);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (search.product) setInput(`Më trego më shumë për produktin "${search.product}".`);
    else if (search.project) setInput(`Çfarë komponentësh më duhen për projektin "${search.project}"?`);
  }, [search.product, search.project]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [busy]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  // Live updates so an admin takeover reply appears instantly
  useEffect(() => {
    if (!conversationId) return;
    const channel = supabase
      .channel(`chat-${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          const row = payload.new as ChatMessage;
          setMessages((prev) => (prev.some((m) => m.id === row.id) ? prev : [...prev, row]));
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [conversationId]);

  const send = async () => {
    const text = input.trim();
    if (!text || busy || !user) return;
    setInput("");
    setBusy(true);
    setNotice(null);
    setMessages((prev) => [
      ...prev,
      {
        id: `local-${Date.now()}`,
        conversation_id: conversationId ?? "",
        sender: "user",
        content: text,
        created_at: new Date().toISOString(),
      },
    ]);

    try {
      const result = await sendChatMessage({ data: { conversationId, message: text } });
      setConversationId(result.conversationId);
      if (result.status === "ok" && result.reply) {
        setMessages((prev) => [
          ...prev,
          {
            id: `ai-${Date.now()}`,
            conversation_id: result.conversationId,
            sender: "ai",
            content: result.reply as string,
            created_at: new Date().toISOString(),
          },
        ]);
      } else if (result.status === "takeover") {
        setNotice("Një administrator e ka marrë bisedën. Prisni përgjigjen e tij këtu.");
      } else if (result.status === "disabled") {
        setNotice("Asistenti AI është çaktivizuar nga administratori.");
      } else if (result.status === "not-configured") {
        setNotice(result.message ?? "Asistenti AI nuk është konfiguruar.");
      } else {
        setNotice(result.message ?? "Ndodhi një gabim.");
      }
    } catch {
      setNotice("Nuk u lidhëm dot me asistentin. Provoni përsëri.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <SiteLayout>
      <div className="mx-auto flex max-w-3xl flex-col px-4 py-8">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-xl gradient-accent">
            <Bot className="size-5 text-primary-foreground" />
          </span>
          <div>
            <h1 className="font-display text-2xl font-bold">Asistenti AI</h1>
            <p className="text-xs text-muted-foreground">
              Zgjedh komponentë, kontrollon stokun real dhe ndërton lista pjesësh.
            </p>
          </div>
        </div>

        {!user ? (
          <div className="mt-8 rounded-xl border border-border bg-card p-8 text-center">
            <p className="font-display text-lg font-semibold">Hyni për të biseduar</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Biseda ruhet në llogarinë tuaj që të mund ta vazhdoni më vonë.
            </p>
            <Button className="mt-5" asChild>
              <Link to="/auth">Hyr në llogari</Link>
            </Button>
          </div>
        ) : (
          <>
            <div className="mt-6 min-h-[50vh] space-y-4 rounded-xl border border-border bg-card p-4">
              {messages.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">
                  {aiSettings?.welcome_message ??
                    "Përshëndetje! Si mund t'ju ndihmoj me projektin tuaj elektronik?"}
                </p>
              ) : null}

              {messages.map((message) => (
                <div
                  key={message.id}
                  className={message.sender === "user" ? "flex justify-end" : "flex gap-3"}
                >
                  {message.sender !== "user" ? (
                    <span className="mt-1 grid size-7 shrink-0 place-items-center rounded-md bg-secondary">
                      {message.sender === "admin" ? (
                        <UserIcon className="size-4 text-primary" />
                      ) : (
                        <Bot className="size-4 text-primary" />
                      )}
                    </span>
                  ) : null}
                  <div
                    className={
                      message.sender === "user"
                        ? "max-w-[80%] whitespace-pre-line rounded-xl bg-primary px-4 py-2.5 text-sm text-primary-foreground"
                        : "max-w-[85%] whitespace-pre-line text-sm leading-relaxed text-foreground"
                    }
                  >
                    {message.sender === "admin" ? (
                      <span className="mb-1 block text-[11px] font-semibold uppercase text-primary">
                        Administratori
                      </span>
                    ) : null}
                    {message.content}
                  </div>
                </div>
              ))}

              {busy ? <p className="animate-pulse text-sm text-muted-foreground">Duke menduar...</p> : null}
              <div ref={bottomRef} />
            </div>

            {notice ? (
              <div className="mt-3 flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm text-warning">
                <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                <span>{notice}</span>
              </div>
            ) : null}

            <div className="mt-4 flex items-end gap-2">
              <Textarea
                ref={inputRef}
                rows={2}
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void send();
                  }
                }}
                placeholder="Përshkruaj projektin tënd ose pyet për një komponent..."
                className="flex-1 resize-none"
              />
              <Button size="icon" disabled={busy || !input.trim()} onClick={() => void send()}>
                <Send className="size-4" />
              </Button>
            </div>
          </>
        )}
      </div>
    </SiteLayout>
  );
}
