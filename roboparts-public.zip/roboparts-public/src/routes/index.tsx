import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Bot, CircuitBoard, PackageCheck, Truck } from "lucide-react";

import { ProductCard } from "@/components/ProductCard";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { categoriesQuery, productsQuery, projectsQuery, settingsQuery } from "@/lib/api";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "eleteonicenginercomponents — Komponentë elektronikë për studentë" },
      {
        name: "description",
        content:
          "Blej Arduino, ESP32, sensorë, ekrane, motorë dhe module komunikimi me gjendje stoku në kohë reale.",
      },
      { property: "og:title", content: "eleteonicenginercomponents" },
      {
        property: "og:description",
        content: "Komponentë elektronikë dhe ide projektesh studentore, me asistent AI.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { data: settings } = useQuery(settingsQuery);
  const { data: categories } = useQuery(categoriesQuery);
  const { data: products } = useQuery(productsQuery());
  const { data: projects } = useQuery(projectsQuery);

  const featured = (products ?? []).filter((p) => p.stock_quantity > 0).slice(0, 8);

  return (
    <SiteLayout>
      <section className="relative overflow-hidden gradient-hero">
        <div className="absolute inset-0 circuit-grid opacity-60" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 lg:py-28">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <CircuitBoard className="size-3.5" /> Komponentë për prototipe reale
          </span>
          <h1 className="mt-5 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
            {settings?.hero_title ?? "Komponentë elektronikë për inxhinierë dhe studentë"}
          </h1>
          <p className="mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            {settings?.hero_subtitle ??
              "Gjithçka që ju nevojitet për prototipet tuaja: Arduino, ESP32, sensorë, ekrane, motorë dhe më shumë."}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" asChild>
              <Link to="/products">
                Shfleto katalogun <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/assistant">
                <Bot className="size-4" /> Pyet asistentin AI
              </Link>
            </Button>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-3">
            {[
              { icon: PackageCheck, title: "Stok në kohë reale", text: "Gjendja përditësohet direkt nga sistemi." },
              { icon: Bot, title: "Ndihmë për projekte", text: "AI të ndihmon të zgjedhësh komponentët e duhur." },
              { icon: Truck, title: "Kërkesë blerjeje", text: "Dërgo kërkesën dhe ne të kontaktojmë." },
            ].map((item) => (
              <div key={item.title} className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur">
                <item.icon className="size-5 text-primary" />
                <p className="mt-3 text-sm font-semibold">{item.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-display text-2xl font-bold">Kategoritë</h2>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/products">Të gjitha <ArrowRight className="size-4" /></Link>
          </Button>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {(categories ?? []).map((category) => (
            <Link
              key={category.id}
              to="/products"
              search={{ category: category.slug }}
              className="group rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/60 hover:shadow-glow"
            >
              <CircuitBoard className="size-5 text-primary transition-transform group-hover:scale-110" />
              <p className="mt-3 text-sm font-semibold">{category.name}</p>
              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{category.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-14">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-display text-2xl font-bold">Produkte të zgjedhura</h2>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/products">Shiko të gjitha <ArrowRight className="size-4" /></Link>
          </Button>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16">
        <div className="rounded-2xl border border-border bg-surface p-6 sm:p-10 circuit-dots">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold">Projekte studentore</h2>
              <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                Ide të gatshme me listën e komponentëve — ideale për detyra kursi dhe diploma.
              </p>
            </div>
            <Button variant="outline" asChild>
              <Link to="/projects">Të gjitha projektet</Link>
            </Button>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {(projects ?? []).slice(0, 3).map((project) => (
              <Link
                key={project.id}
                to="/projects"
                className="rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/60"
              >
                <span className="rounded-md bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                  {project.difficulty}
                </span>
                <p className="mt-3 font-display text-sm font-semibold">{project.title}</p>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{project.summary}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
