import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import type { CartItem } from "@/lib/types";

async function ensureCart(userId: string): Promise<string> {
  const { data: existing, error } = await supabase
    .from("carts")
    .select("id")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  if (existing) return existing.id;
  const { data: created, error: insertError } = await supabase
    .from("carts")
    .insert({ user_id: userId })
    .select("id")
    .single();
  if (insertError) throw insertError;
  return created.id;
}

export function useCart() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const itemsQuery = useQuery({
    queryKey: ["cart", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<CartItem[]> => {
      const cartId = await ensureCart(userId!);
      const { data, error } = await supabase
        .from("cart_items")
        .select("*, products(*)")
        .eq("cart_id", cartId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as CartItem[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["cart", userId] });

  const addItem = useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: string; quantity?: number }) => {
      if (!userId) throw new Error("not-authenticated");
      const cartId = await ensureCart(userId);
      const { data: existing } = await supabase
        .from("cart_items")
        .select("id, quantity")
        .eq("cart_id", cartId)
        .eq("product_id", productId)
        .maybeSingle();
      if (existing) {
        const { error } = await supabase
          .from("cart_items")
          .update({ quantity: existing.quantity + quantity })
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("cart_items")
          .insert({ cart_id: cartId, product_id: productId, quantity });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("U shtua në shportë");
      void invalidate();
    },
    onError: (error: Error) => {
      if (error.message === "not-authenticated") {
        toast.error("Hyni në llogari për të shtuar produkte në shportë");
      } else {
        toast.error("Nuk u shtua dot në shportë");
      }
    },
  });

  const updateQuantity = useMutation({
    mutationFn: async ({ itemId, quantity }: { itemId: string; quantity: number }) => {
      if (quantity <= 0) {
        const { error } = await supabase.from("cart_items").delete().eq("id", itemId);
        if (error) throw error;
        return;
      }
      const { error } = await supabase.from("cart_items").update({ quantity }).eq("id", itemId);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: () => toast.error("Përditësimi dështoi"),
  });

  const removeItem = useMutation({
    mutationFn: async (itemId: string) => {
      const { error } = await supabase.from("cart_items").delete().eq("id", itemId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("U hoq nga shporta");
      void invalidate();
    },
  });

  const clearCart = useMutation({
    mutationFn: async () => {
      if (!userId) return;
      const cartId = await ensureCart(userId);
      const { error } = await supabase.from("cart_items").delete().eq("cart_id", cartId);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const items = itemsQuery.data ?? [];
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const total = items.reduce(
    (sum, item) => sum + Number(item.products?.price ?? 0) * item.quantity,
    0,
  );

  return { items, count, total, isLoading: itemsQuery.isLoading, addItem, updateQuantity, removeItem, clearCart };
}
