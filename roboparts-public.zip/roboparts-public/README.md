# RoboParts Albania — Public Website

Customer-facing electronics components website.

## Deployment
- GitHub: separate repository for the public website
- Netlify: separate site for the public website
- Supabase: use the SAME Supabase project as the admin website

## Environment
Copy `.env.example` to `.env` and provide the public Supabase URL and anon/publishable key.

Product photos are managed from the admin website through Supabase Storage.
